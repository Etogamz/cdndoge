import threading
import asyncio
from flask import Flask, jsonify, send_from_directory, Response
import discord

app = Flask(__name__, static_folder="static")

# === CONFIG ===
DISCORD_USER_ID = 751617471806570497  # your user ID (int)
BOT_TOKEN = "MTI2ODgxMDM4NzE1NjEwNzMwNw.GvRIRK.yi1d0_Gcui-SbWvan_QZiDOC97zxlfQpow43Ms"      # your bot token
FLASK_PORT = 6430

# === PRESENCE STORAGE ===
presence_data = {
    "status": "offline",
    "username": "Loading...",
    "avatar": "https://cdn.discordapp.com/embed/avatars/0.png",
}

# === DISCORD BOT SETUP ===
intents = discord.Intents.default()
intents.presences = True
intents.members = True

client = discord.Client(intents=intents)


@client.event
async def on_ready():
    print(f"[Discord] Logged in as {client.user} ✅")

    # Try to find your member object in mutual guilds
    for guild in client.guilds:
        member = guild.get_member(DISCORD_USER_ID)
        if member:
            presence_data["username"] = member.name
            if member.avatar:
                presence_data["avatar"] = member.avatar.url
            presence_data["status"] = str(member.status)
            print(f"[Presence] Found {member.name}: {member.status}")
            break


@client.event
async def on_presence_update(before, after):
    """Update the cached presence data whenever your status changes"""
    if after.id == DISCORD_USER_ID:
        presence_data["status"] = str(after.status)
        print(f"[Presence] Updated: {after.name} is now {after.status}")


# === BACKGROUND THREAD TO RUN DISCORD BOT ===
def run_discord_bot():
    asyncio.set_event_loop(asyncio.new_event_loop())
    client.run(BOT_TOKEN)


# === FLASK API ROUTES ===
@app.route("/api/discord")
def get_discord():
    return jsonify(presence_data)

@app.route("/")
def serve_home():
    return send_from_directory("static", "index.html")


@app.route("/<path:path>")
def static_files(path):
    return send_from_directory("static", path)


# === MAIN ENTRYPOINT ===
if __name__ == "__main__":
    # Start Discord bot in a separate thread
    bot_thread = threading.Thread(target=run_discord_bot, daemon=True)
    bot_thread.start()

    print(f"[Flask] Running on port {FLASK_PORT}")
    app.run(host="0.0.0.0", port=FLASK_PORT)